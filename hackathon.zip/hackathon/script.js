let publicationSummary = "";
let outputDiv = document.getElementById("summaryOutput");

document.getElementById("generateBtn").addEventListener("click", () => {
  const fileInput = document.getElementById("fileInput");
  const facultyNames = document.getElementById("facultyInput").value.split(",").map(n => n.trim());
  const startYear = parseInt(document.getElementById("startYear").value);
  const endYear = parseInt(document.getElementById("endYear").value);

  if (!fileInput.files[0] || facultyNames.length === 0 || isNaN(startYear) || isNaN(endYear)) {
    alert("Please fill all fields and upload a valid Excel file.");
    return;
  }

  const reader = new FileReader();
  reader.onload = (e) => {
    const data = new Uint8Array(e.target.result);
    const workbook = XLSX.read(data, { type: "array" });
    const sheetName = workbook.SheetNames[0];
    const sheet = workbook.Sheets[sheetName];
    const records = XLSX.utils.sheet_to_json(sheet);

    let summary = `📘 Publication Summary\n\n`;

    facultyNames.forEach((faculty) => {
      const filtered = records.filter(record =>
        record["Faculty Name"] === faculty &&
        record["Publication Year"] >= startYear &&
        record["Publication Year"] <= endYear
      );

      const journals = filtered.filter(r => r["Publication Type"].toLowerCase() === "journal");
      const conferences = filtered.filter(r => r["Publication Type"].toLowerCase() === "conference");

      summary += `👨‍🏫 ${faculty}\n`;
      summary += `- Journals: ${journals.length}\n`;
      summary += `- Conferences: ${conferences.length}\n`;

      filtered.forEach((rec, idx) => {
        summary += `  ${idx + 1}. ${rec["Title"]} (${rec["Publication Year"]}) - ${rec["Journal/Conference Name"]}\n`;
      });

      summary += `\n`;
    });

    publicationSummary = summary;
    outputDiv.textContent = summary;
    outputDiv.classList.remove("hidden");
  };

  reader.readAsArrayBuffer(fileInput.files[0]);
});

document.getElementById("exportWordBtn").addEventListener("click", () => {
  if (!publicationSummary) return alert("No summary generated.");
  const blob = new Blob([publicationSummary], { type: "application/msword" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = "publication_summary.doc";
  link.click();
});

document.getElementById("exportExcelBtn").addEventListener("click", () => {
  if (!publicationSummary) return alert("No summary generated.");
  const csv = publicationSummary.replace(/: /g, ",").replace(/  /g, "");
  const blob = new Blob([csv], { type: "text/csv" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = "publication_summary.csv";
  link.click();
});
